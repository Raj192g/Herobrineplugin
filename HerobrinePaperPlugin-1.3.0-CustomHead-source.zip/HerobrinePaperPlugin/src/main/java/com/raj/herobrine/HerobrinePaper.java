package com.raj.herobrine;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class HerobrinePaper extends JavaPlugin implements Listener, CommandExecutor {
    private static final String HEROBRINE_TEXTURE_VALUE = "ewogICJ0aW1lc3RhbXAiIDogMTc5NDc5NDA0Mzk1NSwKICAicHJvZmlsZUlkIiA6ICIwMmI5NmI1OTdlMDA0OTUyYmM1ZmZjNDUwNmNiNmE0OCIsCiAgInByb2ZpbGVOYW1lIiA6ICJDaGFybGllc3RvbiIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9iY2QwZTQwOTE0ZDZhZDExNGYyNzIwNDIwMjNlNWUyYTQ2MjNmYzMwN2MyMTgxMTkyNjcyN2M2YWI1MjI1ZmJkIgogICAgfQogIH0KfQ==";
    private static final String HEROBRINE_TEXTURE_SIGNATURE = "QDEHKdNVCKOiYJf4/xAAsZBcswjNgk1m/uiGZLYzE8Y67ile17X2sKKgtxN85jhY5eCnEHhopgWh+qSMWZj02U6212PQuHTMYlL+FwNKW2VdWuCMcObyDm9jxAZyMP/O6mSFSvmOdwQZF/jyTghqbbOlmU7gfvpQhQhUP/COtllbm6Pwb0ezf1eTBpDJmJe3H7ucCw97aZWRH4C7fjacIKqs0FZm2R+wvXThwzaVgmJyYFFabiinZWAwG0TmFTpNexTEI4o6h9RNs5ztjWE1O01b3g6JJG668C+luh0Foh+Ug98gzqa65CjiZUd0uDuqY8iGh8ReBJeG6CndkLLc+5YHxyjz0hkX5wr/Y8elOfmQj0lwJDrS2f5x1m73nb3tCtfKJQJ4ROfzTeSx5Bf0VzVDAtE5p0E2ba5xIODayiDdV/6ICS9WVIr0bKwP+qS81OoEDojc1EzT2jPvhPTatNnC99vdnx0DV9oTCFUxtEE1bDdo76BN8QZpHO5ava4Zw4qTgpf/vyeuFjEoZ/0mo+LaCNTHzxfZYyeKpNkkC4zYFcWdy8Xq+EVevekC4eamO/jpCommsSenF6/TWmVJY2TrmlqQvgEau5qytC+bPY8VdEsYEDOxa6YxvV6pxbSnMQhqyrnzLifUUAQARmXFq6yeWy0hwYSwZgEQT/cjNN8=";

    private NamespacedKey maskKey;
    private String owner;
    private final Set<UUID> invisibilityEnabled = new HashSet<UUID>();
    private final Map<UUID, Long> invisibilityCooldown = new HashMap<UUID, Long>();
    private final Map<UUID, Long> blindnessCooldown = new HashMap<UUID, Long>();

    private static final int LIGHTNING_RANGE = 100;
    private static final int TELEPORT_RANGE = 10;
    private static final int BLINDNESS_TARGET_RANGE = 32;
    private static final int EFFECT_COOLDOWN_SECONDS = 15;
    private static final int BLINDNESS_DURATION_SECONDS = 10;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        owner = getConfig().getString("owner", "raj_192g");
        maskKey = new NamespacedKey(this, "herobrine_mask");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("hmask") != null) {
            getCommand("hmask").setExecutor(this);
        }
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                refreshOwnerInvisibility(player);
            }
        }, 20L, 20L);
        getLogger().info("Herobrine powers enabled. Controls: Blaze Rod=Lightning, Ender Pearl=Teleport, Potion=Invisibility, Spider Eye=Blindness.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isOwner(player)) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                showOwnerToEveryone(player);
            }
        }
        invisibilityEnabled.clear();
        invisibilityCooldown.clear();
        blindnessCooldown.clear();
    }

    private boolean isOwner(Player player) {
        return player.getName().equalsIgnoreCase(owner);
    }

    private boolean wearingMask(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null || helmet.getType() != Material.PLAYER_HEAD || !helmet.hasItemMeta()) {
            return false;
        }
        return helmet.getItemMeta().getPersistentDataContainer().has(maskKey, PersistentDataType.BYTE);
    }

    private ItemStack createMask() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(getConfig().getString("mask-name", "§fHerobrine Mask"));
        meta.setLore(Arrays.asList("§7Wear in the helmet slot", "§7Hold a power item and right-click"));
        meta.getPersistentDataContainer().set(maskKey, PersistentDataType.BYTE, (byte) 1);

        // Apply the signed MineSkin texture using the Authlib classes bundled with the server.
        try {
            Class<?> gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
            Class<?> propertyClass = Class.forName("com.mojang.authlib.properties.Property");
            Object profile = gameProfileClass.getConstructor(UUID.class, String.class)
                    .newInstance(UUID.randomUUID(), "Herobrine");
            Object properties = gameProfileClass.getMethod("getProperties").invoke(profile);
            Object textureProperty = propertyClass.getConstructor(String.class, String.class, String.class)
                    .newInstance("textures", HEROBRINE_TEXTURE_VALUE, HEROBRINE_TEXTURE_SIGNATURE);
            properties.getClass().getMethod("put", Object.class, Object.class)
                    .invoke(properties, "textures", textureProperty);

            java.lang.reflect.Field profileField = null;
            Class<?> metaClass = meta.getClass();
            while (metaClass != null && profileField == null) {
                try {
                    profileField = metaClass.getDeclaredField("profile");
                } catch (NoSuchFieldException ignored) {
                    metaClass = metaClass.getSuperclass();
                }
            }
            if (profileField == null) throw new NoSuchFieldException("Skull profile field not found");
            profileField.setAccessible(true);
            profileField.set(meta, profile);
        } catch (Exception ex) {
            getLogger().severe("Could not apply Herobrine head texture: " + ex.getMessage());
        }

        item.setItemMeta(meta);
        return item;
    }

    private void refreshOwnerInvisibility(Player player) {
        if (!isOwner(player)) return;
        UUID id = player.getUniqueId();
        if (!wearingMask(player)) {
            if (invisibilityEnabled.remove(id)) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                showOwnerToEveryone(player);
                player.sendMessage(ChatColor.GRAY + "Herobrine invisibility ended because the mask was removed.");
            }
            return;
        }
        if (invisibilityEnabled.contains(id)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
            hideOwnerFromEveryone(player);
        }
    }

    private void hideOwnerFromEveryone(Player ownerPlayer) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.getUniqueId().equals(ownerPlayer.getUniqueId())) {
                viewer.hidePlayer(this, ownerPlayer);
            }
        }
    }

    private void showOwnerToEveryone(Player ownerPlayer) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.getUniqueId().equals(ownerPlayer.getUniqueId())) {
                viewer.showPlayer(this, ownerPlayer);
            }
        }
    }

    private boolean onCooldown(Map<UUID, Long> cooldowns, Player player) {
        long now = System.currentTimeMillis();
        Long previous = cooldowns.get(player.getUniqueId());
        if (previous != null) {
            long remaining = EFFECT_COOLDOWN_SECONDS * 1000L - (now - previous);
            if (remaining > 0L) {
                player.sendMessage(ChatColor.RED + "Power cooldown: " + ((remaining + 999L) / 1000L) + "s");
                return true;
            }
        }
        cooldowns.put(player.getUniqueId(), now);
        return false;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isOwner(player) || !wearingMask(player)) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = event.getItem();
        if (held == null) return;
        Material material = held.getType();
        if (material != Material.BLAZE_ROD && material != Material.ENDER_PEARL
                && material != Material.POTION && material != Material.SPIDER_EYE) return;

        event.setCancelled(true);
        if (material == Material.BLAZE_ROD) {
            useLightning(player);
        } else if (material == Material.ENDER_PEARL) {
            useTeleport(player);
        } else if (material == Material.POTION) {
            toggleInvisibility(player);
        } else if (material == Material.SPIDER_EYE) {
            useBlindness(player);
        }
    }

    private void useLightning(Player player) {
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();

        // Trace both entities and blocks. The nearest hit wins; if neither is hit,
        // create the lightning at the 100-block endpoint so sky targeting works too.
        RayTraceResult entityTrace = player.getWorld().rayTraceEntities(
                eye, direction, LIGHTNING_RANGE, 0.6,
                entity -> entity instanceof LivingEntity
                        && (entity instanceof Player || entity instanceof Mob)
                        && !entity.getUniqueId().equals(player.getUniqueId()));
        RayTraceResult blockTrace = player.getWorld().rayTraceBlocks(
                eye, direction, LIGHTNING_RANGE, FluidCollisionMode.NEVER, true);

        double entityDistance = Double.MAX_VALUE;
        if (entityTrace != null && entityTrace.getHitPosition() != null) {
            entityDistance = eye.toVector().distance(entityTrace.getHitPosition());
        }
        double blockDistance = Double.MAX_VALUE;
        if (blockTrace != null && blockTrace.getHitPosition() != null) {
            blockDistance = eye.toVector().distance(blockTrace.getHitPosition());
        }

        Location strikeLocation;
        if (entityTrace != null && entityDistance <= blockDistance) {
            strikeLocation = entityTrace.getHitPosition().toLocation(player.getWorld());
        } else if (blockTrace != null && blockTrace.getHitPosition() != null) {
            strikeLocation = blockTrace.getHitPosition().toLocation(player.getWorld());
        } else {
            // If the player aims into open sky, strike the 100-block ray endpoint.
            strikeLocation = eye.clone().add(direction.multiply(LIGHTNING_RANGE));
        }

        // Real vanilla lightning: damages nearby entities and can start fire.
        // No extra manual damage is applied, avoiding double damage.
        player.getWorld().strikeLightning(strikeLocation);
    }

    private void useTeleport(Player player) {
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        RayTraceResult trace = player.getWorld().rayTraceBlocks(eye, direction, TELEPORT_RANGE,
                FluidCollisionMode.NEVER, true);
        Location destination;
        if (trace != null && trace.getHitBlock() != null) {
            Block hit = trace.getHitBlock();
            BlockFace face = trace.getHitBlockFace();
            if (face == null) return;
            destination = hit.getRelative(face).getLocation().add(0.5, 0.0, 0.5);
        } else {
            destination = eye.clone().add(direction.multiply(TELEPORT_RANGE)).getBlock().getLocation().add(0.5, 0.0, 0.5);
        }
        destination.setYaw(player.getLocation().getYaw());
        destination.setPitch(player.getLocation().getPitch());
        if (!isSafe(destination)) {
            player.sendMessage(ChatColor.RED + "No safe teleport position within 10 blocks.");
            return;
        }
        // No sound or particle effects are played.
        player.teleport(destination);
    }

    private boolean isSafe(Location location) {
        World world = location.getWorld();
        if (world == null) return false;
        return location.getBlock().isPassable()
                && location.clone().add(0.0, 1.0, 0.0).getBlock().isPassable()
                && location.clone().subtract(0.0, 1.0, 0.0).getBlock().getType().isSolid();
    }

    private void toggleInvisibility(Player player) {
        UUID id = player.getUniqueId();
        if (onCooldown(invisibilityCooldown, player)) return;
        if (invisibilityEnabled.remove(id)) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
            showOwnerToEveryone(player);
            player.sendMessage(ChatColor.GRAY + "Herobrine invisibility disabled.");
        } else {
            invisibilityEnabled.add(id);
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
            hideOwnerFromEveryone(player);
            player.sendMessage(ChatColor.GREEN + "Herobrine invisibility enabled. Your armor, mask and held items are hidden from other players.");
        }
    }

    private void useBlindness(Player player) {
        if (onCooldown(blindnessCooldown, player)) return;
        Location eye = player.getEyeLocation();
        RayTraceResult result = player.getWorld().rayTraceEntities(eye, eye.getDirection(), BLINDNESS_TARGET_RANGE,
                0.5, entity -> entity instanceof Player && !entity.getUniqueId().equals(player.getUniqueId()));
        if (result == null || !(result.getHitEntity() instanceof Player)) {
            blindnessCooldown.remove(player.getUniqueId());
            player.sendMessage(ChatColor.RED + "Look directly at another player within 32 blocks.");
            return;
        }
        Player target = (Player) result.getHitEntity();
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, BLINDNESS_DURATION_SECONDS * 20,
                0, false, false, false));
        player.sendMessage(ChatColor.GREEN + "Blindness applied to " + target.getName() + " for 10 seconds.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player joined = event.getPlayer();
        if (isOwner(joined)) {
            refreshOwnerInvisibility(joined);
        } else {
            Player ownerPlayer = Bukkit.getPlayerExact(owner);
            if (ownerPlayer != null && wearingMask(ownerPlayer) && invisibilityEnabled.contains(ownerPlayer.getUniqueId())) {
                joined.hidePlayer(this, ownerPlayer);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        invisibilityEnabled.remove(id);
        invisibilityCooldown.remove(id);
        blindnessCooldown.remove(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        Player player = (Player) sender;
        if (!isOwner(player)) {
            player.sendMessage(ChatColor.RED + "You do not have permission.");
            return true;
        }
        if (!command.getName().equalsIgnoreCase("hmask")) return true;
        player.getInventory().addItem(createMask());
        player.sendMessage(ChatColor.GRAY + "Herobrine Mask given. Wear it in the helmet slot. Hold a power item and right-click.");
        return true;
    }
}
