HerobrinePaper 1.1.0 - Paper 1.16.5 / Java 8

Owner: raj_192g (configurable in config.yml)
Wear the Herobrine Mask in the helmet slot. Powers only work for the owner while wearing it.

No GUI controls:
- Hold a Blaze Rod and right-click: visual-only lightning at the targeted block, up to 100 blocks. No cooldown.
- Hold an Ender Pearl and right-click: silent teleport up to 10 blocks. No cooldown.
- Hold a Potion and right-click: toggle invisibility. 15-second cooldown.
- Hold a Spider Eye and right-click while looking at another player: apply blindness for 10 seconds. 15-second cooldown.

When invisibility is enabled, the owner is hidden from other players using Bukkit hidePlayer, which also hides armor, mask and held items. Removing the mask ends invisibility and reveals the owner again.

Get the mask with /hmask. This is the only plugin command; powers themselves are activated with held items and right-click.

The mask currently uses a named player-head item. A custom Herobrine head texture is not included; a texture/skin reference is needed to create that appearance.
