package com.raj.herobrine;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class HerobrinePaper extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey maskKey;
    private String owner;
    private final Set<UUID> invisibilityEnabled = new HashSet<UUID>();
    private final Map<UUID, Long> invisibilityCooldown = new HashMap<UUID, Long>();
    private final Map<UUID, Long> blindnessCooldown = new HashMap<UUID, Long>();

    private static final int LIGHTNING_RANGE = 100;
    private static final int TELEPORT_RANGE = 10;
    private static final int BLINDNESS_TARGET_RANGE = 32;
    private static final int EFFECT_COOLDOWN_SECONDS = 15;
    private static final int BLINDNESS_DURATION_SECONDS = 10;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        owner = getConfig().getString("owner", "raj_192g");
        maskKey = new NamespacedKey(this, "herobrine_mask");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("hmask") != null) {
            getCommand("hmask").setExecutor(this);
        }
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                refreshOwnerInvisibility(player);
            }
        }, 20L, 20L);
        getLogger().info("Herobrine powers enabled. Controls: Blaze Rod=Lightning, Ender Pearl=Teleport, Potion=Invisibility, Spider Eye=Blindness.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isOwner(player)) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                showOwnerToEveryone(player);
            }
        }
        invisibilityEnabled.clear();
        invisibilityCooldown.clear();
        blindnessCooldown.clear();
    }

    private boolean isOwner(Player player) {
        return player.getName().equalsIgnoreCase(owner);
    }

    private boolean wearingMask(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null || helmet.getType() != Material.PLAYER_HEAD || !helmet.hasItemMeta()) {
            return false;
        }
        return helmet.getItemMeta().getPersistentDataContainer().has(maskKey, PersistentDataType.BYTE);
    }

    private ItemStack createMask() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(getConfig().getString("mask-name", "§fHerobrine Mask"));
        meta.setLore(Arrays.asList("§7Wear in the helmet slot", "§7Hold a power item and right-click"));
        meta.getPersistentDataContainer().set(maskKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private void refreshOwnerInvisibility(Player player) {
        if (!isOwner(player)) return;
        UUID id = player.getUniqueId();
        if (!wearingMask(player)) {
            if (invisibilityEnabled.remove(id)) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                showOwnerToEveryone(player);
                player.sendMessage(ChatColor.GRAY + "Herobrine invisibility ended because the mask was removed.");
            }
            return;
        }
        if (invisibilityEnabled.contains(id)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
            hideOwnerFromEveryone(player);
        }
    }

    private void hideOwnerFromEveryone(Player ownerPlayer) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.getUniqueId().equals(ownerPlayer.getUniqueId())) {
                viewer.hidePlayer(this, ownerPlayer);
            }
        }
    }

    private void showOwnerToEveryone(Player ownerPlayer) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.getUniqueId().equals(ownerPlayer.getUniqueId())) {
                viewer.showPlayer(this, ownerPlayer);
            }
        }
    }

    private boolean onCooldown(Map<UUID, Long> cooldowns, Player player) {
        long now = System.currentTimeMillis();
        Long previous = cooldowns.get(player.getUniqueId());
        if (previous != null) {
            long remaining = EFFECT_COOLDOWN_SECONDS * 1000L - (now - previous);
            if (remaining > 0L) {
                player.sendMessage(ChatColor.RED + "Power cooldown: " + ((remaining + 999L) / 1000L) + "s");
                return true;
            }
        }
        cooldowns.put(player.getUniqueId(), now);
        return false;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isOwner(player) || !wearingMask(player)) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = event.getItem();
        if (held == null) return;
        Material material = held.getType();
        if (material != Material.BLAZE_ROD && material != Material.ENDER_PEARL
                && material != Material.POTION && material != Material.SPIDER_EYE) return;

        event.setCancelled(true);
        if (material == Material.BLAZE_ROD) {
            useLightning(player);
        } else if (material == Material.ENDER_PEARL) {
            useTeleport(player);
        } else if (material == Material.POTION) {
            toggleInvisibility(player);
        } else if (material == Material.SPIDER_EYE) {
            useBlindness(player);
        }
    }

    private void useLightning(Player player) {
        Block target = player.getTargetBlockExact(LIGHTNING_RANGE, FluidCollisionMode.NEVER);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "No block visible within 100 blocks.");
            return;
        }
        // Visual-only lightning: no entity damage and no fire.
        player.getWorld().strikeLightningEffect(target.getLocation().add(0.5, 0.0, 0.5));
    }

    private void useTeleport(Player player) {
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        RayTraceResult trace = player.getWorld().rayTraceBlocks(eye, direction, TELEPORT_RANGE,
                FluidCollisionMode.NEVER, true);
        Location destination;
        if (trace != null && trace.getHitBlock() != null) {
            Block hit = trace.getHitBlock();
            BlockFace face = trace.getHitBlockFace();
            if (face == null) return;
            destination = hit.getRelative(face).getLocation().add(0.5, 0.0, 0.5);
        } else {
            destination = eye.clone().add(direction.multiply(TELEPORT_RANGE)).getBlock().getLocation().add(0.5, 0.0, 0.5);
        }
        destination.setYaw(player.getLocation().getYaw());
        destination.setPitch(player.getLocation().getPitch());
        if (!isSafe(destination)) {
            player.sendMessage(ChatColor.RED + "No safe teleport position within 10 blocks.");
            return;
        }
        // No sound or particle effects are played.
        player.teleport(destination);
    }

    private boolean isSafe(Location location) {
        World world = location.getWorld();
        if (world == null) return false;
        return location.getBlock().isPassable()
                && location.clone().add(0.0, 1.0, 0.0).getBlock().isPassable()
                && location.clone().subtract(0.0, 1.0, 0.0).getBlock().getType().isSolid();
    }

    private void toggleInvisibility(Player player) {
        UUID id = player.getUniqueId();
        if (onCooldown(invisibilityCooldown, player)) return;
        if (invisibilityEnabled.remove(id)) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
            showOwnerToEveryone(player);
            player.sendMessage(ChatColor.GRAY + "Herobrine invisibility disabled.");
        } else {
            invisibilityEnabled.add(id);
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
            hideOwnerFromEveryone(player);
            player.sendMessage(ChatColor.GREEN + "Herobrine invisibility enabled. Your armor, mask and held items are hidden from other players.");
        }
    }

    private void useBlindness(Player player) {
        if (onCooldown(blindnessCooldown, player)) return;
        Location eye = player.getEyeLocation();
        RayTraceResult result = player.getWorld().rayTraceEntities(eye, eye.getDirection(), BLINDNESS_TARGET_RANGE,
                0.5, entity -> entity instanceof Player && !entity.getUniqueId().equals(player.getUniqueId()));
        if (result == null || !(result.getHitEntity() instanceof Player)) {
            blindnessCooldown.remove(player.getUniqueId());
            player.sendMessage(ChatColor.RED + "Look directly at another player within 32 blocks.");
            return;
        }
        Player target = (Player) result.getHitEntity();
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, BLINDNESS_DURATION_SECONDS * 20,
                0, false, false, false));
        player.sendMessage(ChatColor.GREEN + "Blindness applied to " + target.getName() + " for 10 seconds.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player joined = event.getPlayer();
        if (isOwner(joined)) {
            refreshOwnerInvisibility(joined);
        } else {
            Player ownerPlayer = Bukkit.getPlayerExact(owner);
            if (ownerPlayer != null && wearingMask(ownerPlayer) && invisibilityEnabled.contains(ownerPlayer.getUniqueId())) {
                joined.hidePlayer(this, ownerPlayer);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        invisibilityEnabled.remove(id);
        invisibilityCooldown.remove(id);
        blindnessCooldown.remove(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        Player player = (Player) sender;
        if (!isOwner(player)) {
            player.sendMessage(ChatColor.RED + "You do not have permission.");
            return true;
        }
        if (!command.getName().equalsIgnoreCase("hmask")) return true;
        player.getInventory().addItem(createMask());
        player.sendMessage(ChatColor.GRAY + "Herobrine Mask given. Wear it in the helmet slot. Hold a power item and right-click.");
        return true;
    }
}
