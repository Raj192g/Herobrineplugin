package com.raj.herobrine;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.util.RayTraceResult;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

public class HerobrinePaper extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey maskKey;
    private final Map<UUID, Long> lastTeleport = new HashMap<UUID, Long>();
    private ProtocolManager protocol;
    private String owner;

    @Override public void onEnable() {
        saveDefaultConfig();
        owner = getConfig().getString("owner", "raj_192g");
        maskKey = new NamespacedKey(this, "herobrine_mask");
        getServer().getPluginManager().registerEvents(this, this);
        for (String c : Arrays.asList("hmask", "hlightning", "hinvisible", "htabhide", "htp")) getCommand(c).setExecutor(this);
        Bukkit.getScheduler().runTaskTimer(this, () -> { for (Player p : Bukkit.getOnlinePlayers()) if (isOwner(p)) refreshEffects(p); }, 20L, 20L);
        if (getServer().getPluginManager().getPlugin("ProtocolLib") != null) {
            protocol = ProtocolLibrary.getProtocolManager();
            // Suppress outgoing PlayerInfo ADD packets for the owner only; entity visibility is unchanged.
            protocol.addPacketListener(new PacketAdapter(this, PacketType.Play.Server.PLAYER_INFO) {
                @Override public void onPacketSending(PacketEvent event) {
                    if (!getConfig().getBoolean("hide-owner-from-tab", true)) return;
                    if (event.getPacket().getPlayerInfoAction().read(0) != EnumWrappers.PlayerInfoAction.ADD_PLAYER) return;
                    String hidden = getConfig().getString("owner", "raj_192g");
                    if (event.getPacket().getPlayerInfoDataLists().read(0).stream().anyMatch(d -> d.getProfile().getName().equalsIgnoreCase(hidden))) event.setCancelled(true);
                }
            });
        } else getLogger().warning("ProtocolLib not found: TAB-only hiding is disabled. Install ProtocolLib compatible with this server build.");
    }

    private boolean isOwner(Player p) { return p.getName().equalsIgnoreCase(owner); }
    private boolean wearingMask(Player p) { ItemStack h=p.getInventory().getHelmet(); return h!=null && h.getType()==Material.PLAYER_HEAD && h.hasItemMeta() && h.getItemMeta().getPersistentDataContainer().has(maskKey, PersistentDataType.BYTE); }
    private ItemStack createMask() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD); ItemMeta meta=item.getItemMeta();
        meta.setDisplayName(getConfig().getString("mask-name", "§fHerobrine Mask"));
        meta.setLore(Arrays.asList("§7Wear in the helmet slot", "§7Right-click while held to silent-teleport"));
        meta.getPersistentDataContainer().set(maskKey, PersistentDataType.BYTE, (byte)1); item.setItemMeta(meta); return item;
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) { if (isOwner(e.getPlayer())) refreshEffects(e.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { lastTeleport.remove(e.getPlayer().getUniqueId()); }
    // Armor state is checked periodically so removing the mask removes the powers.
    @Override public void onDisable() { if (protocol != null) protocol.removePacketListeners(this); }

    private void refreshEffects(Player p) {
        if (!isOwner(p)) return;
        if (wearingMask(p)) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, false, false));
        } else {
            p.removePotionEffect(PotionEffectType.INVISIBILITY); p.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }

    @EventHandler public void onInteract(PlayerInteractEvent e) {
        Player p=e.getPlayer(); if (!isOwner(p) || !wearingMask(p)) return;
        if (e.getAction()!=Action.RIGHT_CLICK_AIR && e.getAction()!=Action.RIGHT_CLICK_BLOCK) return;
        ItemStack hand=e.getItem();
        // Right-click with an empty hand while wearing the mask.
        if (hand!=null && hand.getType()!=Material.AIR) return;
        e.setCancelled(true); silentTeleport(p);
    }

    private void silentTeleport(Player p) {
        long now=System.currentTimeMillis(); long cd=getConfig().getLong("teleport-cooldown-seconds",2)*1000L;
        Long prev=lastTeleport.get(p.getUniqueId()); if(prev!=null && now-prev<cd) return;
        int range=getConfig().getInt("teleport-range",32);
        RayTraceResult trace=p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), range, FluidCollisionMode.NEVER, true);
        Location dest;
        if(trace!=null && trace.getHitBlock()!=null) {
            Block hit=trace.getHitBlock(); BlockFace face=trace.getHitBlockFace();
            dest=hit.getRelative(face).getLocation().add(0.5,0,0.5);
        } else dest=p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(range)).getBlock().getLocation().add(0.5,0,0.5);
        dest.setYaw(p.getLocation().getYaw()); dest.setPitch(p.getLocation().getPitch());
        if(!safe(dest)) return;
        p.teleport(dest); lastTeleport.put(p.getUniqueId(),now); // intentionally no sound or particles
    }
    private boolean safe(Location l) {
        if(l.getWorld()==null) return false;
        return l.getBlock().isPassable() && l.clone().add(0,1,0).getBlock().isPassable() && l.clone().subtract(0,1,0).getBlock().getType().isSolid();
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        Player p=(Player)sender; if(!isOwner(p)) { p.sendMessage(ChatColor.RED+"You do not have permission."); return true; }
        if(command.getName().equalsIgnoreCase("hmask")) { p.getInventory().addItem(createMask()); p.sendMessage(ChatColor.GRAY+"Herobrine Mask given."); return true; }
        if(!wearingMask(p)) { p.sendMessage(ChatColor.RED+"Wear the Herobrine Mask first."); return true; }
        if(command.getName().equalsIgnoreCase("htp")) { silentTeleport(p); return true; }
        if(command.getName().equalsIgnoreCase("hlightning")) {
            Block b=p.getTargetBlockExact(getConfig().getInt("lightning-range",100)); if(b==null) { p.sendMessage(ChatColor.RED+"No block in range."); return true; }
            p.getWorld().strikeLightningEffect(b.getLocation().add(0.5,0,0.5)); return true;
        }
        if(command.getName().equalsIgnoreCase("hinvisible")) {
            if(p.hasPotionEffect(PotionEffectType.INVISIBILITY)) { p.removePotionEffect(PotionEffectType.INVISIBILITY); p.removePotionEffect(PotionEffectType.BLINDNESS); }
            else { p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false, false)); p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false)); }
            return true;
        }
        if(command.getName().equalsIgnoreCase("htabhide")) { p.sendMessage(protocol==null?ChatColor.RED+"Install ProtocolLib first.":ChatColor.GREEN+"TAB-only hiding is configured for the owner."); return true; }
        return true;
    }

}
