package com.raj.herobrine;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;

import java.util.*;

public class HerobrinePaper extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey maskKey;
    private ProtocolManager protocol;
    private String owner;
    private final Map<UUID, Long> lastTeleport = new HashMap<UUID, Long>();
    private final Set<UUID> invisibilityEnabled = new HashSet<UUID>();

    private enum GuiType { POWERS, BLINDNESS_TARGETS }
    private static class HerobrineGui implements InventoryHolder {
        private final GuiType type;
        private Inventory inventory;
        HerobrineGui(GuiType type) { this.type = type; }
        public Inventory getInventory() { return inventory; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        owner = getConfig().getString("owner", "raj_192g");
        maskKey = new NamespacedKey(this, "herobrine_mask");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("hmask") != null) getCommand("hmask").setExecutor(this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) refreshEffects(p);
        }, 20L, 20L);
        if (getServer().getPluginManager().getPlugin("ProtocolLib") != null) {
            protocol = ProtocolLibrary.getProtocolManager();
            protocol.addPacketListener(new PacketAdapter(this, PacketType.Play.Server.PLAYER_INFO) {
                @Override public void onPacketSending(PacketEvent event) {
                    if (!getConfig().getBoolean("hide-owner-from-tab", true)) return;
                    if (event.getPacket().getPlayerInfoAction().read(0) != EnumWrappers.PlayerInfoAction.ADD_PLAYER) return;
                    String hidden = getConfig().getString("owner", "raj_192g");
                    if (event.getPacket().getPlayerInfoDataLists().read(0).stream().anyMatch(d -> d.getProfile().getName().equalsIgnoreCase(hidden))) event.setCancelled(true);
                }
            });
        } else getLogger().warning("ProtocolLib not found: TAB-only hiding is disabled.");
    }

    @Override public void onDisable() {
        if (protocol != null) protocol.removePacketListeners(this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isOwner(p)) {
                p.removePotionEffect(PotionEffectType.INVISIBILITY);
                p.removePotionEffect(PotionEffectType.BLINDNESS);
            }
        }
    }

    private boolean isOwner(Player p) { return p.getName().equalsIgnoreCase(owner); }
    private boolean wearingMask(Player p) {
        ItemStack h = p.getInventory().getHelmet();
        return h != null && h.getType() == Material.PLAYER_HEAD && h.hasItemMeta()
                && h.getItemMeta().getPersistentDataContainer().has(maskKey, PersistentDataType.BYTE);
    }

    private ItemStack namedItem(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.RESET + name);
        meta.setLore(Collections.singletonList(ChatColor.GRAY + lore));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createMask() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(getConfig().getString("mask-name", "§fHerobrine Mask"));
        meta.setLore(Arrays.asList("§7Wear in the helmet slot", "§7Right-click with an empty hand to open powers"));
        meta.getPersistentDataContainer().set(maskKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private void refreshEffects(Player p) {
        if (!isOwner(p)) return;
        if (wearingMask(p) && invisibilityEnabled.contains(p.getUniqueId())) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
        } else {
            p.removePotionEffect(PotionEffectType.INVISIBILITY);
            if (!wearingMask(p)) invisibilityEnabled.remove(p.getUniqueId());
        }
        // The mask never applies blindness to its wearer.
        p.removePotionEffect(PotionEffectType.BLINDNESS);
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { if (isOwner(e.getPlayer())) refreshEffects(e.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        lastTeleport.remove(e.getPlayer().getUniqueId());
        invisibilityEnabled.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!isOwner(p) || !wearingMask(p)) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack hand = e.getItem();
        if (hand != null && hand.getType() != Material.AIR) return;
        e.setCancelled(true);
        openPowersGui(p);
    }

    private void openPowersGui(Player p) {
        HerobrineGui holder = new HerobrineGui(GuiType.POWERS);
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.DARK_RED + "Herobrine Powers");
        holder.inventory = inv;
        inv.setItem(10, namedItem(Material.ENDER_PEARL, "Teleport", "Silent teleport up to 32 blocks"));
        inv.setItem(12, namedItem(Material.LIGHTNING_ROD, "Lightning", "Visual lightning; no damage or fire"));
        inv.setItem(14, namedItem(Material.POTION, "Invisibility", invisibilityEnabled.contains(p.getUniqueId()) ? "Turn invisibility off" : "Turn invisibility on"));
        inv.setItem(16, namedItem(Material.BLACK_DYE, "Blindness", "Choose another online player"));
        p.openInventory(inv);
    }

    private void openBlindnessTargets(Player ownerPlayer) {
        List<Player> targets = new ArrayList<Player>();
        for (Player online : Bukkit.getOnlinePlayers()) if (!isOwner(online) && !online.getUniqueId().equals(ownerPlayer.getUniqueId())) targets.add(online);
        if (targets.isEmpty()) { ownerPlayer.sendMessage(ChatColor.RED + "No other players are online."); return; }
        int size = Math.min(54, Math.max(9, ((targets.size() + 8) / 9) * 9));
        HerobrineGui holder = new HerobrineGui(GuiType.BLINDNESS_TARGETS);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.DARK_GRAY + "Choose a player");
        holder.inventory = inv;
        for (int i = 0; i < targets.size() && i < size; i++) {
            Player target = targets.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta meta = head.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + target.getName());
            meta.setLore(Collections.singletonList(ChatColor.GRAY + "Click to apply blindness"));
            head.setItemMeta(meta);
            inv.setItem(i, head);
        }
        ownerPlayer.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof HerobrineGui)) return;
        e.setCancelled(true);
        Player p = (Player) e.getWhoClicked();
        if (!isOwner(p) || !wearingMask(p) || e.getClickedInventory() != top || e.getCurrentItem() == null) return;
        HerobrineGui gui = (HerobrineGui) top.getHolder();
        int slot = e.getRawSlot();
        if (gui.type == GuiType.POWERS) {
            if (slot == 10) { p.closeInventory(); silentTeleport(p); }
            else if (slot == 12) { p.closeInventory(); useLightning(p); }
            else if (slot == 14) {
                UUID id = p.getUniqueId();
                if (invisibilityEnabled.contains(id)) { invisibilityEnabled.remove(id); p.removePotionEffect(PotionEffectType.INVISIBILITY); p.sendMessage(ChatColor.GRAY + "Invisibility disabled."); }
                else { invisibilityEnabled.add(id); refreshEffects(p); p.sendMessage(ChatColor.GREEN + "Invisibility enabled."); }
                openPowersGui(p);
            } else if (slot == 16) openBlindnessTargets(p);
        } else if (gui.type == GuiType.BLINDNESS_TARGETS) {
            String targetName = ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName());
            Player target = Bukkit.getPlayerExact(targetName);
            if (target == null || isOwner(target) || target.getUniqueId().equals(p.getUniqueId())) {
                p.sendMessage(ChatColor.RED + "That player is not available.");
            } else {
                target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 10, 0, false, false, false));
                p.sendMessage(ChatColor.GREEN + "Blindness applied to " + target.getName() + " for 10 seconds.");
            }
            p.closeInventory();
        }
    }

    @EventHandler public void onInventoryDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof HerobrineGui) e.setCancelled(true);
    }

    private void useLightning(Player p) {
        Block b = p.getTargetBlockExact(getConfig().getInt("lightning-range", 100));
        if (b == null) { p.sendMessage(ChatColor.RED + "No block in range."); return; }
        p.getWorld().strikeLightningEffect(b.getLocation().add(0.5, 0, 0.5));
    }

    private void silentTeleport(Player p) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("teleport-cooldown-seconds", 2) * 1000L;
        Long prev = lastTeleport.get(p.getUniqueId());
        if (prev != null && now - prev < cd) return;
        int range = getConfig().getInt("teleport-range", 32);
        RayTraceResult trace = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), range, FluidCollisionMode.NEVER, true);
        Location dest;
        if (trace != null && trace.getHitBlock() != null) {
            Block hit = trace.getHitBlock();
            BlockFace face = trace.getHitBlockFace();
            dest = hit.getRelative(face).getLocation().add(0.5, 0, 0.5);
        } else {
            dest = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(range)).getBlock().getLocation().add(0.5, 0, 0.5);
        }
        dest.setYaw(p.getLocation().getYaw());
        dest.setPitch(p.getLocation().getPitch());
        if (!safe(dest)) { p.sendMessage(ChatColor.RED + "No safe teleport spot found."); return; }
        p.teleport(dest);
        lastTeleport.put(p.getUniqueId(), now);
    }

    private boolean safe(Location l) {
        return l.getWorld() != null && l.getBlock().isPassable()
                && l.clone().add(0, 1, 0).getBlock().isPassable()
                && l.clone().subtract(0, 1, 0).getBlock().getType().isSolid();
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        Player p = (Player) sender;
        if (!isOwner(p)) { p.sendMessage(ChatColor.RED + "You do not have permission."); return true; }
        if (!command.getName().equalsIgnoreCase("hmask")) return true;
        p.getInventory().addItem(createMask());
        p.sendMessage(ChatColor.GRAY + "Herobrine Mask given. Wear it in your helmet slot, then right-click with an empty hand to open powers.");
        return true;
    }
}
