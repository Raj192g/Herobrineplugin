HEROBRINE PAPER PLUGIN - SOURCE PROJECT (NOT A READY-TO-INSTALL JAR)

Target: Paper 1.16.5 / Java 8
Owner configured by default: raj_192g

Features attempted in this starter source:
- /hmask gives a named player-head mask; wear it in the helmet slot.
- Right-click with an empty hand while wearing the mask, or use /htp, for silent teleport.
- Teleport ray-traces up to the configured range and checks a basic safe landing spot.
- /hlightning calls visual-only lightning at the targeted block (no thunder damage).
- /hinvisible toggles invisibility and blindness potion effects.
- Mask powers are owner-gated and effects are refreshed while online.
- Optional ProtocolLib hook attempts TAB-list-only filtering for the owner.

IMPORTANT:
- This is Java source + Maven project, not a compiled .jar.
- Build locally with Maven or use the included GitHub Actions workflow. See BUILD_ON_GITHUB.txt.
- The mask is currently a named player head. A custom Herobrine face requires a resource pack / custom head texture; no texture is included.
- Lightning command uses strikeLightningEffect (visual only, no damage).
- Teleport is a simplified silent ray-trace approximation; it is not an exact reproduction of the original Forge mod.
- The TAB filtering hook is unverified with the exact Paper 1.16.5 and ProtocolLib build. Do not rely on it until tested.
- Back up the server before testing. Prefer a private test copy first.

Commands:
/hmask
/htp
/hlightning
/hinvisible
/htabhide
